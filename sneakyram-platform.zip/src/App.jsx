import { Routes, Route } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import Login from "./pages/auth/Login";
import Dashboard from "./pages/Dashboard";
import SkillTree from "./pages/Learn/SkillTree";
import Community from "./pages/Community";
import Profile from "./pages/Profile";
import RequireAuth from "./components/RequireAuth";

export default function App() {
  return (
    <>
      <Header />
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/community" element={<Community />} />
        <Route path="/u/:username" element={<Profile />} />
        <Route
          path="/dashboard"
          element={
            <RequireAuth>
              <Dashboard />
            </RequireAuth>
          }
        />
        <Route path="/learn/tree" element={<SkillTree />} />
      </Routes>
      <Footer />
    </>
  );
}