import { Link } from "react-router-dom";

export default function Header() {
  return (
    <header style={{ padding: 16, borderBottom: "1px solid #222" }}>
      <Link to="/">SneakyRam</Link> |{" "}
      <Link to="/learn/tree">Learn</Link> |{" "}
      <Link to="/community">Community</Link> |{" "}
      <Link to="/dashboard">Dashboard</Link>
    </header>
  );
}