export default function Footer() {
  return (
    <footer style={{ padding: 16, borderTop: "1px solid #222", marginTop: 40 }}>
      © SneakyRam
    </footer>
  );
}