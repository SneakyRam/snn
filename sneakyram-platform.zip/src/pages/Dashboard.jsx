export default function Dashboard() {
  return <h1 style={{ padding: 40 }}>Dashboard</h1>;
}