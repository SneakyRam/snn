import { supabase } from "../../lib/supabase";

export default function Login() {
  async function login() {
    await supabase.auth.signInWithOAuth({ provider: "github" });
  }

  return (
    <div style={{ padding: 40 }}>
      <h2>Login</h2>
      <button onClick={login}>Login with GitHub</button>
    </div>
  );
}