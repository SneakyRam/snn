export default function Community() {
  return <h1 style={{ padding: 40 }}>Community</h1>;
}